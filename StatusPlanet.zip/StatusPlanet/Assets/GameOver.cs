﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;

public class GameOver : MonoBehaviour
{

    public Text yearText;

    //public SceneFader sceneFader;

    void OnEnable()
    {
        StartCoroutine(AnimateText());
    }

    IEnumerator AnimateText()
    {
        yearText.text = "2006";
        int currentYear = 2006;
        int finalYear = GameController.year;

        yield return new WaitForSeconds(2);

        while (currentYear < finalYear)
        {
            currentYear++;
            yearText.text = currentYear.ToString();

            yield return new WaitForSeconds(0.05f);
        }
    }

    public void Replay()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void Menu()
    {
        SceneManager.LoadScene(0);
    }

}
