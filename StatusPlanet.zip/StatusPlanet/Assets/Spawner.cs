﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Spawner : MonoBehaviour {
    
    private float timeUntilNextSpawn;
    private float spawnInterval;
    public float initialSpawnInterval = 5f;
    public float spawnIntervalDiff = 0.1f;
    public float spawnIntervalMin = 0.6f;

    public Transform satellite;
    public Transform[] spawners;

    public Transform playerTransform;
    public Player player;

    private float angleMultiplier;

    void Start () {
        timeUntilNextSpawn = 0f;
        spawnInterval = initialSpawnInterval;
        angleMultiplier = Mathf.PI / 4;
	}
	
	void Update () {
        timeUntilNextSpawn -= Time.deltaTime;
        if (timeUntilNextSpawn <= 0f)
        {
            if (!GameController.gameOver)
            {
                Spawn();
            }
            spawnInterval -= spawnIntervalDiff * spawnInterval;
            if (spawnInterval <= spawnIntervalMin)
            {
                spawnInterval = spawnIntervalMin;
            }
            
            timeUntilNextSpawn = spawnInterval + timeUntilNextSpawn;
        }
	}

    void Spawn()
    {
        int index = Random.Range(0, 8);
        Transform _satellite = Instantiate(satellite, spawners[index].position, spawners[index].rotation);
        SatelliteController sc = _satellite.GetComponent<SatelliteController>();
        sc.setPlayer(playerTransform, player);

        //Finding anlges depending on spawn point and direction
        float radius = (float)Random.Range(2, 5);
        radius *= 2f;
        sc.transform.localScale *= (4f + radius) / 12f;
        int direction = Random.Range(0, 2);
        //direction = 0;
        if (direction == 0)
        {
            radius *= -1;
            sc.setTimerStartValue(((float)index) * angleMultiplier + (angleMultiplier * 4));
            sc.setOrbitRadius(radius);
        }
        else
        {
            sc.setTimerStartValue(((float)index) * angleMultiplier);
            sc.setOrbitRadius(radius);
        }
    }

}
