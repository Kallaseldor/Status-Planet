﻿using UnityEngine;

public class Missile : MonoBehaviour {

    public float speed = 5f;
    public Vector3 target;

    public Explosion explosion;

    void Update()
    {
        Vector3 dir = target - transform.position;
        float distanceThisFrame = speed * Time.deltaTime;

        if (dir.magnitude <= distanceThisFrame)
        {
            Explode();
            return;
        }

        transform.Translate(dir.normalized * distanceThisFrame, Space.World);
        transform.LookAt(target);
    }

    public void SetTarget(Vector3 _target)
    {
        target = _target;
        //Debug.Log(velocity);
    }

    void Explode()
    {
        explosion.gameObject.SetActive(true);
        Destroy(gameObject, 1.25f * explosion.getExplosionTime());
    }

}
