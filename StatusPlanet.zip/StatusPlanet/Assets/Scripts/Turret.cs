﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Turret : MonoBehaviour {

    public Transform firePoint;
    public GameObject missilePrefab;
    public Vector3 targetPoint;         //Mouse position
    public float lookSpeed = 5f;

    private float shootCooldownTimer = 0f;
    public float shootCooldown = 0.75f;

    public GameObject fireEffect;

    void FixedUpdate()
    {
        shootCooldownTimer -= Time.deltaTime;
        lookAtMouse();
        
        if (Input.GetMouseButtonDown(0) && !GameController.gameOver)
        {
            if (shootCooldownTimer <= 0f)
            {
                shootCooldownTimer = shootCooldown;
                Shoot();
            }
        }
    }

    void lookAtMouse()
    {
        Plane playerPlane = new Plane(Vector3.up, transform.position);
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

        float hitdist = 0.0f;
        if (playerPlane.Raycast(ray, out hitdist))
        {
            targetPoint = ray.GetPoint(hitdist);
            Quaternion targetRotation = Quaternion.LookRotation(targetPoint - transform.position);
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, lookSpeed * Time.deltaTime);
        }
    }

    void Shoot()
    {
        GameObject bulletGO = (GameObject)Instantiate(missilePrefab, firePoint.position, firePoint.rotation);
        Missile _missile = bulletGO.GetComponent<Missile>();

        if (_missile != null)
        {
            _missile.SetTarget(targetPoint);
        }

        //Effect for firing the weapon
        //GameObject effectIns = (GameObject)Instantiate(fireEffect, transform.position, transform.rotation);
        //Destroy(effectIns, 5f);
    }

}
