﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TesteCollider : MonoBehaviour {

	void OnCollisionEnter()
    {
        Debug.Log("Entrei aqui");
    }
}
