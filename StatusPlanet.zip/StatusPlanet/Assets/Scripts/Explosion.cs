﻿using UnityEngine;

public class Explosion : MonoBehaviour {

    public float growAmount = 3f;
    public float explosionTime = 1.5f;
    private float currentTime;

    public Material material;
    public Color color;

    public SpawnMeteor spawnMeteor;

    public string satelliteColliderTag = "SatelliteCollider";

    void Start()
    {
        currentTime = 0f;
    }

	void Update()
    {
        currentTime += Time.deltaTime;
        
        if (currentTime < explosionTime)
        {
            transform.localScale += new Vector3(growAmount, growAmount, growAmount) * Time.deltaTime;
        }
        else
        {
            //color.a = 255f * (3f - currentTime * 1.5f * explosionTime);
            //Renderer rend = GetComponent<Renderer>();
            //rend.material.SetColor(0, color);
            transform.localScale -= new Vector3(growAmount, growAmount, growAmount) * Time.deltaTime * 4;
        }
    }

    void OnCollisionEnter(Collision col)
    {
        //Debug.Log("Entrou na funcao");
        //if(col.gameObject.tag == satelliteColliderTag)
        //{

        //spawnMeteor.Charge();
        Destroy(col.gameObject.GetComponent<SatelliteColliderReference>().getSatelliteController().gameObject);
        SpawnMeteor.Charge();
        //}
    }

    public float getExplosionTime()
    {
        return explosionTime;
    }
}
