﻿using UnityEngine;
using UnityEngine.UI;

public class Player : MonoBehaviour {

    public float initHealth = 100f;
    private float health;

    public Image healthBar;
    public GameObject notText;

    public GameController gameController;
    private bool gameIsOver;

    public bool isMenu = false;

    void Start()
    {
        health = initHealth;
        healthBar.fillAmount = 1f;
        gameIsOver = false;
    }

    public void TakeDamage(float _dmg)
    {
        health -= _dmg;
        healthBar.fillAmount = health / initHealth;

        if (health <= 0)
        {
            GameOver();
        }
    }

    public void GameOver()
    {
        if (gameIsOver || isMenu)
        {
            return;
        }
        gameIsOver = true;
        notText.SetActive(true);
        gameController.GameOver();
    }
    


}
