﻿using UnityEngine;
using System.Collections;

public class SatelliteController : MonoBehaviour
{
    [Header("References")]
    public Transform playerTransform;
    public Player player;
    public LineRenderer lineRenderer;
    public ParticleSystem impactEffect;
    public Transform firePoint;
    private Vector3 initialPosition;

    [Header("Movement Stuff")]
    public float offOrbitSpeed = 2f;
    public float orbitSpeed = 2f;
    private float angleSpeed;
    public float angle = 0f;
    private float orbitRadius = 5f;
    private bool isOrbiting;


    private float timeCounter;
    public float timeCounterStartValue;

    private bool isDead;

    public float damageOverTime = 2.5f;

    

    void Start()
    {
        //angleSpeed = (2 * Mathf.PI * orbitRadius) / orbitSpeed;
        angleSpeed = orbitSpeed / (Mathf.PI * orbitRadius);
        isOrbiting = false;
        isDead = false;
        transform.LookAt(playerTransform);
    }

    void Update()
    {
        //Discover whether the distance at this time is enought to orbit
        if (!isOrbiting && (playerTransform.position - transform.position).sqrMagnitude <= orbitRadius * orbitRadius)
        {
            isOrbiting = true;
            timeCounter = timeCounterStartValue;
            if (orbitRadius >= 0f)
            {
                initialPosition = transform.position.normalized * (transform.position.magnitude - orbitRadius);
            }
            else
            {
                initialPosition = transform.position.normalized * (transform.position.magnitude + orbitRadius);
            }
            
        }

        //Decide which movement to make
        if (isOrbiting)
        {
            inOrbitMovement();
            Laser();
        }
        else
        {
            moveStraightToPlanet();
        }
    }

    void inOrbitMovement()
    {
        timeCounter += Time.deltaTime * angleSpeed;

        float x = Mathf.Sin(timeCounter) * orbitRadius;
        float z = Mathf.Cos(timeCounter) * orbitRadius;

        transform.position = initialPosition + (new Vector3(x, 0, z));
        //transform.Translate(new Vector3 (x, 0, z) * Time.deltaTime, Space.World);
        transform.LookAt(playerTransform);
    }

    void moveStraightToPlanet()
    {
        //TEMPORARY CODE: MAKES SATELLITE GO STRAIGHT INTO THE PLANET AND STOP WHEN REACHES ORBIT RADIUS
        float distThisFrame = offOrbitSpeed * Time.deltaTime;
        Vector3 dir = playerTransform.position - transform.position;
        if (distThisFrame >= dir.magnitude)
        {
            distThisFrame = dir.magnitude * Time.deltaTime;
        }
        transform.Translate(dir.normalized * distThisFrame, Space.World);
    }

    void Laser()
    {
        //Dano
        player.TakeDamage(damageOverTime * Time.deltaTime * GameController.getDamageModifier());

        //Graficos
        //Laser
        if (!lineRenderer.enabled)
        {
            lineRenderer.enabled = true;
        }
        lineRenderer.SetPosition(0, firePoint.position);
        lineRenderer.SetPosition(1, playerTransform.position);

        //Impacto
        Vector3 _dir = firePoint.position - playerTransform.position;
        impactEffect.transform.rotation = Quaternion.LookRotation(_dir);
        impactEffect.transform.position = playerTransform.position + _dir.normalized * 0.9f;
    }

    public void setPlayer(Transform _playerTransform, Player _player)
    {
        player = _player;
        playerTransform = _playerTransform;
    }

    public void setTimerStartValue(float _v)
    {
        timeCounterStartValue = _v;
    }

    public void setOrbitRadius(float _r)
    {
        orbitRadius = _r;
    }

    /*public Transform planetPosition;

    public float velocity;
    private float angle;
    public float distance;
    public float orbitDistance = 7f;

    // Update is called once per frame
    void Update()
    {
        if (distance >= orbitDistance)
            distance -= 0.01f;
        float x = player.position.x + distance * Mathf.Cos(angle);
        float y = 0;
        float z = player.position.z + distance * Mathf.Sin(angle);
        angle += velocity;
        transform.position = new Vector3(x, 0, z) * Time.deltaTime;
    }*/

    public void Kill()
    {
        if (isDead)
        {
            return;
        }
        isDead = true;
        lineRenderer.enabled = false;
        //Declarar efeitos de especiais
        Destroy(gameObject);
        //continuar aqui
    }

}
