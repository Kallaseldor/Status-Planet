﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SatelliteColliderReference : MonoBehaviour {

    public SatelliteController satelliteController;

    public SatelliteController getSatelliteController()
    {
        return satelliteController;
    }
}
