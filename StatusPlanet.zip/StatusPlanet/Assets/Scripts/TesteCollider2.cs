﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TesteCollider2 : MonoBehaviour {

    void Update()
    {
        transform.Translate(new Vector3(0, 0, -Time.deltaTime * 0.5f));
    }

    void OnCollisionEnter()
    {
        Debug.Log("Entrei aqui");
    }
}
