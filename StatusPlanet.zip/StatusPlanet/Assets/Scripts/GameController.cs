﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class GameController : MonoBehaviour
{

    public static float damageModifier = 1f;
    public static int year = 2006;
    public int highScore;
    private float scoreTimer;

    public float scoreInterval = 5f;
    public float scoreIntervalDiff = 0.05f;
    public float scoreIntervalMin = 1f;

    public Text scoreText;
    public Text highScoreText;

    public GameObject gameOverCanvas;
    public GameObject UI;

    public static bool gameOver;

    private bool hasActivatedGameOverUI;
    public bool isMenu = false;


    void Start()
    {

        gameOver = false;
        hasActivatedGameOverUI = false;
        //Score initial settings
        scoreText.text = "Year: 2006";
        scoreTimer = scoreInterval;

        //Setting high score values
        if (PlayerPrefs.GetInt("highScore") == 0)
        {
            PlayerPrefs.SetInt("highScore", 2006);
            highScore = 2006;
        }
        else
        {
            highScore = PlayerPrefs.GetInt("highScore");
        }
        highScoreText.text = "Best: " + highScore.ToString();
    }

    void Update()
    {
        UpdateScore();
    }

    

    void UpdateScore()
    {
        if (gameOver || isMenu)
        {
            return;
        }
        scoreTimer -= Time.deltaTime;
        if (scoreTimer <= 0f)
        {
            year++;
            UpdateScoreText();
            scoreInterval -= scoreInterval * scoreIntervalDiff;
            if (scoreInterval <= scoreIntervalMin)
            {
                scoreInterval = scoreIntervalMin;
            }
            scoreTimer = scoreInterval + scoreTimer;
        }
    }

    void UpdateScoreText()
    {
        scoreText.text = "Year: " + year.ToString();
        if (year > highScore)
        {
            highScoreText.text = "Best: " + year.ToString();
            highScore = year;
        }
    }


    public static float getDamageModifier()
    {
        return damageModifier;
    }

    public void GameOver()
    {
        if (gameOver || isMenu)
        {
            return;
        }
        gameOver = true;
        if (highScore > PlayerPrefs.GetInt("highScore"))
        {
            PlayerPrefs.SetInt("highScore", highScore);
        }
        StartCoroutine(EnableGameOverUI());

        //gameOver.SetEnabled(true);
    }

    IEnumerator EnableGameOverUI()
    {
        yield return new WaitForSeconds(2f);
        if (!hasActivatedGameOverUI)
        {
            hasActivatedGameOverUI = true;
            gameOverCanvas.SetActive(true);
            //UI.SetActive(false);
        }
    }


    /*public static float orbitRadius = 7f;

    public static float getOrbitRadius()
    {
        return orbitRadius;
    }*/
}
