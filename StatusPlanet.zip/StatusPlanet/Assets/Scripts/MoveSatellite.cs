﻿using UnityEngine;
using System.Collections;

public class MoveSatellite : MonoBehaviour
{

    public Transform player;

    public float offOrbitSpeed = 2f;
    public float orbitSpeed = 2f;

    private float angleSpeed;
    public float angle = 0f;

    private float orbitRadius;
    private bool isOrbiting;
    
    private float timeCounter;
    public float timeCounterStartValue;

    private bool isDead;

    private Vector3 initialPosition;

    void Start()
    {
        //angleSpeed = (2 * Mathf.PI * orbitRadius) / orbitSpeed;
        angleSpeed = orbitSpeed / (Mathf.PI * orbitRadius);
        isOrbiting = false;
        isDead = false;
        transform.LookAt(player);
        timeCounterStartValue = 0f;
    }

    void Update()
    {
        //Discover whether the distance at this time is enought to orbit
        if (!isOrbiting && (player.position - transform.position).magnitude <= orbitRadius)
        {
            isOrbiting = true;
            timeCounter = timeCounterStartValue;
            initialPosition = transform.position.normalized * (transform.position.magnitude - orbitRadius);
        }

        //Decide which movement to make
        if (isOrbiting)
        {
            inOrbitMovement();
        }
        else
        {
            moveStraightToPlanet();
        }
    }

    void inOrbitMovement()
    {
        timeCounter += Time.deltaTime * angleSpeed;

        float x = Mathf.Sin(timeCounter) * orbitRadius;
        float z = Mathf.Cos(timeCounter) * orbitRadius;
        
        transform.position = initialPosition + (new Vector3(x, 0, z));
        //transform.Translate(new Vector3 (x, 0, z) * Time.deltaTime, Space.World);
        transform.LookAt(player);
    }

    void moveStraightToPlanet()
    {
        //TEMPORARY CODE: MAKES SATELLITE GO STRAIGHT INTO THE PLANET AND STOP WHEN REACHES ORBIT RADIUS
        float distThisFrame = offOrbitSpeed * Time.deltaTime;
        Vector3 dir = player.position - transform.position;
        if (distThisFrame >= dir.magnitude)
        {
            distThisFrame = dir.magnitude * Time.deltaTime;
        }
        transform.Translate(dir.normalized * distThisFrame, Space.World);
    }
    /*public Transform planetPosition;

    public float velocity;
    private float angle;
    public float distance;
    public float orbitDistance = 7f;

    // Update is called once per frame
    void Update()
    {
        if (distance >= orbitDistance)
            distance -= 0.01f;
        float x = player.position.x + distance * Mathf.Cos(angle);
        float y = 0;
        float z = player.position.z + distance * Mathf.Sin(angle);
        angle += velocity;
        transform.position = new Vector3(x, 0, z) * Time.deltaTime;
    }*/

    void Kill()
    {
        if(isDead)
        {
            return;
        }
        isDead = true;

        //continuar aqui
    }

}
