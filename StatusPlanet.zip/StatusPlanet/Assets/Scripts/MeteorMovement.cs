﻿using UnityEngine;
using System.Collections;

public class MoveComet : MonoBehaviour
{
    private float distance;
    public float distanceOrbit;
    public float velocity;
    public Transform cometPosition;
    public Transform planetPosition;
    private float angle = 0;
    private float angle2 = 0;
    private float angle3 = 0;

    void Start()
    {
        float distanceX = (cometPosition.position.x - planetPosition.position.x) * (cometPosition.position.x - planetPosition.position.x);
        float distanceY = (cometPosition.position.y - planetPosition.position.y) * (cometPosition.position.y - planetPosition.position.y);
        float distanceZ = (cometPosition.position.z - planetPosition.position.z) * (cometPosition.position.z - planetPosition.position.z);
        distance = Mathf.Sqrt((distanceX + distanceY + distanceZ));
        angle2 = Mathf.Atan2(cometPosition.position.z, cometPosition.position.x);
    }

    void Update()
    {
        velocity += 1f * Time.deltaTime;
        if (distance >= distanceOrbit)
        { //Chegando na orbita do planeta
          //float x = cometPosition.position.x - (velocity * Mathf.Sin (angle2));
          //float z = cometPosition.position.z - (velocity * Mathf.Cos (angle2));
          //cometPosition.position = new Vector3 (x, 0, z);
            float x = distance * Mathf.Sin(angle + angle2);
            float z = distance * Mathf.Cos(angle + angle2);
            angle += (velocity / (2 * Mathf.PI));
            cometPosition.position = new Vector3(x, 0, z);
            float distanceX = (cometPosition.position.x - planetPosition.position.x) * (cometPosition.position.x - planetPosition.position.x);
            float distanceY = (cometPosition.position.y - planetPosition.position.y) * (cometPosition.position.y - planetPosition.position.y);
            float distanceZ = (cometPosition.position.z - planetPosition.position.z) * (cometPosition.position.z - planetPosition.position.z);
            distance = Mathf.Sqrt((distanceX + distanceY + distanceZ)) - velocity;
        }
        else
        {
            if (angle3 >= 2.0f * Mathf.PI)
            {//Saindo da orbita do planeta
                float x = cometPosition.position.x + (velocity * Mathf.Cos(angle + angle3 + angle2));
                float z = cometPosition.position.z - (velocity * Mathf.Sin(angle + angle3 + angle2));
                cometPosition.position = new Vector3(x, 0, z);
            }
            else
            {//Orbitando o planeta
                float x = distance * Mathf.Sin(angle3 + angle + angle2);
                float z = distance * Mathf.Cos(angle3 + angle + angle2);
                angle3 += (velocity / (2 * Mathf.PI));
                cometPosition.position = new Vector3(x, 0, z);
            }
        }

        if ((transform.position - planetPosition.position).sqrMagnitude >= 1000000)
        {
            Destroy(gameObject);
        }

    }

}
