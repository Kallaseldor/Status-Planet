﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ImagesExposition : MonoBehaviour
{

    public Image[] images;
    public int index;

    void Start()
    {
        index = 7;
        StartCoroutine(Next());
    }

    IEnumerator Next()
    {
        while (true)
        {
            yield return new WaitForSeconds(3f);
            Debug.Log("Click");
            if (index == 0)
            {
                SceneManager.LoadScene(1);
            }
            else
            {
                images[index].gameObject.SetActive(false);
            }
            index--;
        }
    }

}
