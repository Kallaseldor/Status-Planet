﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SpawnMeteor : MonoBehaviour {

    public Transform meteor;
    public Transform meteorSpawnPosition;

    public Transform playerTransform;

    public Image meteorBar;

    public static int c = 20;
    public static int maxC = 20;

    void Start()
    {
        c = maxC;
        meteorBar.fillAmount = 1f;
    }

    void Update()
    {
        meteorBar.fillAmount = ((float)c) / ((float)maxC);
        if (Input.GetKeyDown(KeyCode.Space) && c == maxC)
        {
            Spawn();
            c = 0;
            meteorBar.fillAmount = 0f;
        }
    }

    void Spawn()
    {
        Transform _meteor = Instantiate(meteor, meteorSpawnPosition.position, meteorSpawnPosition.rotation);
        MeteorMovement sc = _meteor.GetComponent<MeteorMovement>();
        sc.SetTarget(playerTransform);
    }

    public static void Charge()
    {
        c++;
        if (c > maxC)
        {
            c = maxC;
        }
    }
}
