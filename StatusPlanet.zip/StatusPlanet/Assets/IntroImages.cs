﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class IntroImages : MonoBehaviour {

    public Image[] images;
    public Image expo;
    public int index;

    void Start()
    {
        index = 0;
        expo = images[0];
    }

    void Next()
    {
        index++;
        if (index == 7)
        {
            SceneManager.LoadScene(1);
        }
        else
        {
            expo = images[index];
        }
    }
	
}
